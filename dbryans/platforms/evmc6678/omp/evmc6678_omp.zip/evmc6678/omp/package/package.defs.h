/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y30
 */

#ifndef evmc6678_omp__
#define evmc6678_omp__



#endif /* evmc6678_omp__ */ 
