/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y30
 */

#ifndef omp_MSMCRAM__
#define omp_MSMCRAM__



#endif /* omp_MSMCRAM__ */ 
