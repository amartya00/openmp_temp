/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y30
 */

#ifndef omp_no_ddr__
#define omp_no_ddr__



#endif /* omp_no_ddr__ */ 
