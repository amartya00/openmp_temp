/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y30
 */

#ifndef c6678_omp__
#define c6678_omp__



#endif /* c6678_omp__ */ 
