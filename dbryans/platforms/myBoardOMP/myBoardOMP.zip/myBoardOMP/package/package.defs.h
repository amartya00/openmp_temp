/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y30
 */

#ifndef myBoardOMP__
#define myBoardOMP__



#endif /* myBoardOMP__ */ 
