/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-x20
 */

#ifndef evmc6678__
#define evmc6678__



#endif /* evmc6678__ */ 
