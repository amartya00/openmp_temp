/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y44
 */

#ifndef evmc6678Omp__
#define evmc6678Omp__



#endif /* evmc6678Omp__ */ 
